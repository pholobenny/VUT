package vut.question3.pholo.a210124385pholopetveterinary;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class pet_activity extends AppCompatActivity {
    private RadioButton Cat;
    private RadioButton Dog;
    private EditText PetName;
    private EditText Age;
    private EditText Display;
    private Button Calculate;
    private Button Clear;
    private Button Exit;
    private final double consultationFeeDog = 205.0;
    private final double consultationFeeCat = 155.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_activity);

        Cat = (RadioButton) findViewById(R.id.rdbCat);
        Dog = (RadioButton) findViewById(R.id.rdbDog);
        PetName = (EditText) findViewById(R.id.etName);
        Age = (EditText) findViewById(R.id.etAge);
        Display = (EditText) findViewById(R.id.etDisplay);
        Calculate = (Button) findViewById(R.id.btnCalc);
        Clear = (Button) findViewById(R.id.btnClear);
        Exit = (Button) findViewById(R.id.btnExit);

        Calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    if (PetName.getText().equals("") || PetName.getText().toString().isEmpty()){
                        PetName.setError("Pet name is required");
                        throw new IllegalArgumentException("Invalid pet name");
                    }else if(Age.getText().equals("") ||Age.getText().toString().isEmpty()){
                        Age.setError("Age is reqiured");
                        throw new IllegalArgumentException("Invalid Age");
                    }
                    double price = calculatePrice(Integer.parseInt(Age.getText().toString()));
                    String type="";
                    if (Cat.isChecked()){
                        type ="Cat";
                    }else if (Dog.isChecked()){
                        type= "Dog";
                    }
                    Display.setText("Name:"+PetName.getText()+"\n" +
                            "Type:"+type+"\n" +
                            "Age:"+Age.getText()+"\n" +
                            "Price:"+price);

                }catch (Exception ex){
                Context context = getApplicationContext();
                Toast toast = Toast.makeText(context,ex.getMessage(),Toast.LENGTH_LONG);
                toast.show();
            }
            }
        });

        Clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clear();
            }
        });

        Exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                exit();
            }
        });


    }

    public double calculatePrice(int age){
        int discount =0;
        double price=0.0,tempPrice;
        if(Dog.isChecked()){
            if (age <4){
                discount = 10;
            }else if (age >=4 && age<=8){
                discount = 15;
            }else if (age>8){
                discount= 20;
            }
            tempPrice = consultationFeeDog * discount/100;
            price = consultationFeeDog - tempPrice;
        }else if(Cat.isChecked()){
            if (age <5){
                discount = 9;
            }else if (age >=5 && age<=9){
                discount = 13;
            }else if (age>8){
                discount= 18;
            }
            tempPrice = consultationFeeCat * discount/100;
            price = consultationFeeCat - tempPrice;
        }
        return  price;
    }

    public void clear(){
        Display.setText("");
        PetName.setText("");
        Age.setText("");
        Cat.setSelected(true);
        Dog.setSelected(false);
    }

    public void exit(){
        Intent intent = new Intent(pet_activity.this,MainActivity.class);
        startActivity(intent);
    }


}
